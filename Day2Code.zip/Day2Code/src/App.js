import logo from './logo.svg';
import './App.css';
import Header from "./Header";
import Footer from "./Footer";
import ProductDisplay from './ProductDisplay';
import React from 'react';

// component -- return a virtual DOM
function App() {
  return (
    <React.Fragment>
      <Header></Header> 
      <ProductDisplay></ProductDisplay>
      <Footer></Footer>
   </React.Fragment>
  );
}

export default App;
// npx create-react-app first_project