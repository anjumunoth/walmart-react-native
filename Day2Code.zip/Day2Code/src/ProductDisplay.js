import React,{Component} from 'react'

class ProductDisplay extends Component{
    addToCartEventHandler=()=>{
        alert("Button clicked");
    }

    render()
    {
        var productsArr=[
            {productId:"P101",productName:"Apple 13 mini",description:"Apple mini 13 256gb, grey colour",price:85678,quantity:12,imageUrl:"images/iphone13Mini.jpg"},
            {productId:"P102",productName:"Samsung fold3",description:"Samsung fold3 256gb, grey colour",price:145678,quantity:7,imageUrl:"images/samsungFold3.jpg"},
            {productId:"P103",productName:"One plus 8t",description:"One plus 8t 256gb, grey colour",price:65678,quantity:5,imageUrl:"images/oneplus8t.jpg"},
            {productId:"P104",productName:"Google pixel",description:"Google pixel 256gb, grey colour",price:50000,quantity:3,imageUrl:"images/googlePixel.jpg"}
        ];
        var cardsArr=productsArr.map(item => {
            return (
                <div className='card bg-warning m-2 border border-5 border-primary' style={{width:"18rem"}}>
                        <img src={item.imageUrl} 
                        alt={item.description}
                        className='card-img-top' style={imgStyle} />
                        <div className='card-body'>
                            <h1 className='card-title'>{item.productName}</h1>
                            <p className='card-text'> Price : Rs.{item.price}</p>
                            <p className='card-text'> Quantity : Rs.{item.quantity}</p>
                            <input type="button" value="Add To Cart" className='btn btn-primary' 
                            onClick={()=>{ this.addToCartEventHandler();}}
                             />
                        </div>
                    </div>
            );
         });
        var imgStyle={width:"150px", height:"100px",margin:"auto", border:"2px solid blue",borderRadius:"50%"};
        return  (
        <React.Fragment>
            <h1 >Products Information</h1>
            <div className='container'> 
                <div className='row'>
                    {cardsArr}
                </div>
            </div>
        </React.Fragment>
        );
    }
}

export default ProductDisplay;

// dynamic rendering
/*
depending upon the number of elements, the corresponding number of rows have to be generated

var arr=[10,20,30,40,50];
var resultArr=arr.map(item => item*item);
console.log(resultArr);//[100,400,900,1600,2500];


*/