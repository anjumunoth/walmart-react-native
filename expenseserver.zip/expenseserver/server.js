const express = require('express') 
const cors=require('cors')
const errorhandler = require('errorhandler')
const bodyParser = require('body-parser')
const expenses = require("./routes/expenses")
const PORT=4000;


let store = {
  expenses: [
        { expenseId: 1, expenseTitle: "title1", description: "description1", amount: 1234, paymentStatus: "true", category: "General", expenseDate: new Date() },
        { expenseId: 2, expenseTitle: "title2", description: "description2", amount: 1234, paymentStatus: "true", category: "General", expenseDate: new Date() },
        { expenseId: 3, expenseTitle: "title3", description: "description3", amount: 1234, paymentStatus: "true", category: "General", expenseDate: new Date() },
        { expenseId: 4, expenseTitle: "title4", description: "description4", amount: 1234, paymentStatus: "true", category: "General", expenseDate: new Date() },
        { expenseId: 5, expenseTitle: "title5", description: "description5", amount: 1234, paymentStatus: "true", category: "General", expenseDate: new Date() },
    ]
  }


let app = express()
app.use(cors());
app.use(bodyParser.json())
app.use(express.urlencoded({extended:false}));
app.use(errorhandler())
app.use((req, res, next) => {
  req.store = store;
  if(req.method == "POST")
  {
  console.log("Req in middleware",req);
  }
  next()
})
app.get('/expenses',expenses.getExpenses)
app.post('/expenses', expenses.addExpense)
app.put('/expenses/:expenseId', expenses.updateExpense)
app.delete('/expenses/:expenseId', expenses.removeExpense)



app.listen(4000,()=>{
  console.log(`Server is running at ${PORT}`);
})