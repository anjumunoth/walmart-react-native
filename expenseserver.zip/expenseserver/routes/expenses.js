module.exports = {
  getExpenses(req, res) {
    res.status(200).send(req.store.expenses)
  },
  addExpense(req, res) {
    console.log("data in post",req);
	let newExpense = req.body;
  
	
    if(req.store.expenses.length ==0)
    {
      newExpense.expenseId=1;
    }
    else
    {
      newExpense.expenseId=req.store.expenses[req.store.expenses.length-1].expenseId +1
    }
    req.store.expenses.push(newExpense)
    res.status(201).send("Expense details added successfully")  
  },
  updateExpense(req, res) {
    var updatedExpense=JSON.parse(req.body);
    var pos= req.store.expenses.findIndex(item => item.expenseId == req.params.expenseId);
    if(pos >=0)
    {
      req.store.expenses.splice(pos,1,updatedExpense);
      res.status(200).send("Expense details updated successfully")  
    }
    else
    {
      res.status(401).send("Expense details for the expenseId not found")  
    }
   
  },
  removeExpense(req, res) {
    var pos= req.store.expenses.findIndex(item => item.expenseId == req.params.expenseId);
    if(pos >=0)
    {
      req.store.expenses.splice(pos,1);
      res.status(200).send("Expense details deleted successfully")  
    }
    else
    {
      res.status(401).send("Expense details for the expenseId not found")  
    }
  }
}