import React from 'react'

class Footer extends React.Component
{
    render()
    {
        return (
            <div className='container-fluid bg-warning text-primary'>
                <h1>@copyrights anju munoth @2021
                    </h1>
            </div>
        );

    }
}
export default Footer