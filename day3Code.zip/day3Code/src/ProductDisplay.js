import React,{Component} from 'react'
import AddToCart,{Sample} from './AddToCart';

class ProductDisplay extends Component{
    constructor()
    {
        super();
        this.ctr=100;
        this.state={showAddToCart:false,selectedProduct:{}};
        
        //this --> component's object
        this.detailsEventHandler=this.detailsEventHandler.bind(this);
    }
    addToCartEventHandler=(selectedObj)=>{
        alert("Add To cart button clicked"+selectedObj.productId);
        //this.showAddToCart=true;
        //alert("Show Add To Cart: "+ this.showAddToCart);//true
        // call render method (showAddToCart: true -- AddToCart will be mounted)
        // will always call render method implicitly only
        // call the setState() method ; setState() internally will call the render method
        this.setState({showAddToCart:true},()=>{
            console.log("Show add to cart : "+this.state.showAddToCart);// true;
        });
        this.setState({selectedProduct:selectedObj});
        
    }
    detailsEventHandler=function(selectedObj){
        alert("Details button clicked"+selectedObj.productId);

    }
    render()
    {
        var productsArr=[
            {productId:"P101",productName:"Apple 13 mini",description:"Apple mini 13 256gb, grey colour",price:85678,quantity:12,imageUrl:"images/iphone13Mini.jpg"},
            {productId:"P102",productName:"Samsung fold3",description:"Samsung fold3 256gb, grey colour",price:145678,quantity:7,imageUrl:"images/samsungFold3.jpg"},
            {productId:"P103",productName:"One plus 8t",description:"One plus 8t 256gb, grey colour",price:65678,quantity:5,imageUrl:"images/oneplus8t.jpg"},
            {productId:"P104",productName:"Google pixel",description:"Google pixel 256gb, grey colour",price:50000,quantity:3,imageUrl:"images/googlePixel.jpg"}
        ];
        var cardsArr=productsArr.map(item => {
            return (
                <div className='card bg-warning m-2 border border-5 border-primary' style={{width:"18rem"}}>
                        <img src={item.imageUrl} 
                        alt={item.description}
                        className='card-img-top' style={imgStyle} />
                        <div className='card-body'>
                            <h1 className='card-title'>{item.productName}</h1>
                            <p className='card-text'> Price : Rs.{item.price}</p>
                            <p className='card-text'> Quantity : {item.quantity}</p>
                            <input type="button" value="Add To Cart" className='btn btn-primary' 
                            onClick={()=>{ this.addToCartEventHandler(item);}} />
                            <input type="button" value="Details" className='btn btn-primary m-2' 
                            onClick={this.detailsEventHandler.bind(this,item)}  />
                        </div>
                    </div>
            );
         });
        var imgStyle={width:"150px", height:"100px",margin:"auto", border:"2px solid blue",borderRadius:"50%"};
        return  (
        <React.Fragment>
            <h1 >Products Information</h1>
            <div className='container'> 
                <div className='row'>
                    {cardsArr}
                </div>
            </div>
            
            {this.state.showAddToCart ?<AddToCart companyName="walmart" selectedProduct={this.state.selectedProduct}></AddToCart>:null}
        </React.Fragment>
        );
    }
}

export default ProductDisplay;

// dynamic rendering
/*
depending upon the number of elements, the corresponding number of rows have to be generated

var arr=[10,20,30,40,50];
var resultArr=arr.map(item => item*item);
console.log(resultArr);//[100,400,900,1600,2500];


*/
/*
diff b/w anonymous function and lambda function
lambda function : scope of "this"-- lexical scope
*/


/*
conditional rendering
based on a condition
2 ways of conditional rendering
1. ternary operator
 {this.showAddToCart ?<AddToCart></AddToCart>:null}
  {this.showAddToCart ?<AddToCart></AddToCart>:<Sample></Sample>}
2. logical and operator
 {this.showAddToCart && <AddToCart></AddToCart>}

 showAddToCart - true and ctr >100 -- AddToCart

 {this.showAddToCart? ctr>100 > <AddToCart></AddToCart>:<Sample></Sample>:<Example></Example>

As part of JSX, the following not allowed
1. for loop 
2. loops
3. if-else, switch
4. return, goto 
5. function
*/

/*
int i=2,j=5,k=10;
if(i>j && ++k >100)
{
    SOP("i is the greatest");
}

SOP(k);//10
*/

/*
State of a component 
-- hold the mutable data of that particular component
-- Is always an object
-- Initialised within the constructor

How to change the state:
Call the setState() method 

setState method
-- 2 tasks
-- a. modify the state
-- b. call the render method implicitly

-- take 2 params
-- 1st param -- object/function
-- 2nd param -- optional ; callback function -- 
    function which is implicitly executed on the completion of the execution setState method

-- async function
-- 1st param -- object -- the object will be merged with the state and will become the new state
-- send an object -- assignment
-- send a function -- updation on basis of previous values
update emp set salary=1000;

update emp set salary=salary+100;

var i=10;
function myFunc(){
    console.log("I "+i);
}
myFunc();//10
i++;


*/

/*
Async function

function myasyncFunc()
{
    console.log("hello");
    setInterval(()=>{
        console.log("hi");
    },2000);
    console.log("bye");

}
myasyncFunc(); // hello,bye,hi

var obj1={empId:101};
var obj2={salary:5678};
var obj3={empId:999,salary:500};
var obj4={...obj1,...obj2};//{empId:101,salary:5678};
var obj5={...obj1,...obj3};//{empId:999,salary:500}
var obj6={...obj3,...obj1};//{empId:101,salary:500}
var obj7={...obj3,...{empName:"sara"}};//{empId:999,salary:500,empName:"sara"}
*/