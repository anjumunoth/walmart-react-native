import React from 'react'

class Register extends React.Component {
    constructor(props)
    {
        super(props);
        this.state={ctr:1,bgColor:null,username:"",password:"",confirmPassword:"",employeeId:"",errorEmployeeId:"",email:""}
        this.confirmPasswordRef=React.createRef();
    }
    handleUsernameChangeEventHandler=(event)=>{
        console.log(event);
        console.log(event.target.value);
        this.setState({username:event.target.value});
    }
    handlePasswordChangeEventHandler=(event)=>{
        this.setState({password:event.target.value,ctr:2});
    }
    shouldComponentUpdate(){
        if(this.state.ctr ==2)
            return true;
        else
            return false;
    }
    handleEmployeeIdChangeEventHandler=(event)=>{

        var tempId=event.target.value;
        if(tempId.startsWith("W"))
        {
            this.setState({employeeId:event.target.value,errorEmployeeId:""});
        }
        else
        {
            this.setState({errorEmployeeId:"Employee Id should always start with W"});
        }
    }
    handleEmailChangeEventHandler=(event)=>{
        console.log("Input Event for emailId"+event.target.value)
        this.setState({email:event.target.value,bgColor:null});
    }
    changeBgEventHandler=()=>{
        this.setState({bgColor:"yellow"});
    }
    copyHandleEventHandler=(event)=>{
        event.preventDefault();
        return false;
    }
    registerEventHandler=()=>{
        console.log("Username "+ this.state.username);
        console.log("Password "+ this.state.password);
        console.log("Confirm Password "+ this.confirmPasswordRef.current.value);

    }
    handleEmailIdChange = (event)=>{
        // console.log(value);
        if(event.target.value === ""){
            this.setState({errorEmailId:"Email Required!"});
        }
    if(!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(event.target.value))){
        this.setState({errorEmailId:"Invalid Email"});
    }else if(!event.target.value.endsWith("@walmart.com")){
        this.setState({errorEmailId:"Invalid Walmart Domain"});
    }
    else{
        this.setState({email:event.target.value,errorEmailId:""});
    }
    }

    render() {
        return (
            <React.Fragment>
                <div className='container-fluid bg-warning'>
                    <div className='row'>
                        <h1 className='text-primary col-4 offset-4 mb-5'> Register</h1>
                    </div>
                    <div className='row'>
                        <div className='col-4 offset-4 border border-5 border-primary'>
                            <form>
                                <div className='mb-3'>
                                    <label className='form-label'>Username</label>
                                    <input type="text" className='form-control' onChange={this.handleUsernameChangeEventHandler} />
                                </div>
                                <div className='mb-3'>
                                    <label className='form-label'>Password</label>
                                    <input type="text" className='form-control' 
                                        onChange={this.handlePasswordChangeEventHandler} 
                                        onCopy={this.copyHandleEventHandler}/>
                                </div>
                                <div className='mb-3'>
                                    <label className='form-label'>Confirm Password</label>
                                    <input type="text" className='form-control' 
                                    ref={this.confirmPasswordRef}
                                    onPaste={(ev)=>{ev.preventDefault(); return false;}} />
                                </div>
                                <div className='mb-3'>
                                    <label className='form-label'>Employee Id</label>
                                    <input type="text" className='form-control' onChange={this.handleEmployeeIdChangeEventHandler} />
                                    {this.state.errorEmployeeId.length >0 &&<div className='form-text'>
                                        {this.state.errorEmployeeId}
                                    </div>}
                                </div>
                                <div className='mb-3'>
                                    <label className='form-label'>EmailId</label>
                                    <input type="text" style={{backgroundColor:this.state.bgColor}} className='form-control' 
                                    onBlur={this.handleEmailChangeEventHandler} 
                                    onFocus={this.changeBgEventHandler} />
                                </div>
                                
                                <div className='mb-3'>
                                    <input type="button" value="Register" className='btn btn-primary' onClick={this.registerEventHandler} />
                                </div>
                                
                            </form>
                            <h2> Hello {this.state.username}</h2>
                        </div>
                    </div>

                </div>
            </React.Fragment>
        );
    }
}

export default Register;

/*
Controlled components
--setState ; inbuilt events in the form 

Uncontrolled component

*/
/*
Android studio
Expo

*/

/*
lifecycle methods:
1. getDerivedStateFromProps -- method is executed when 1.first time the component gets loaded after the constructor before the render 2.props changed
2. componentDidMount -- 1. executed only once, after the REAL dom has been created(after the render) -- subscription , do ansync calls to API
3. render -- executed multiple times -- heart of the component -- return the virtual DOM
4. constructor -- executed only once -- initialise the members -- initialise the state -- first member method to be executed when the component is mounted
5. componentDidUpdate -- each time component has finished the updation  -- multiple times -- called after the rEAL DOM has beeen updated
6. shouldComponentUpdate -- will return a boolean value ; only if it returns true -- updation process continues

*/