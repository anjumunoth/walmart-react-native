import logo from './logo.svg';
import './App.css';
import Header from "./Header";
import Footer from "./Footer";
import ProductDisplay from './ProductDisplay';
import React from 'react';
import Cart from './Cart';
import Register from './Register';
import ProductEdit from "./ProductEdit"

// component -- return a virtual DOM
class App extends React.Component {
  constructor()
  {
    super();
    this.state={
      showCart:false,
      cartArr:[],
      productsArr:[
        {productId:"P101",productName:"Apple 13 mini",description:"Apple mini 13 256gb, grey colour",price:85678,quantity:12,imageUrl:"images/iphone13Mini.jpg"},
        {productId:"P102",productName:"Samsung fold3",description:"Samsung fold3 256gb, grey colour",price:145678,quantity:7,imageUrl:"images/samsungFold3.jpg"},
        {productId:"P103",productName:"One plus 8t",description:"One plus 8t 256gb, grey colour",price:65678,quantity:5,imageUrl:"images/oneplus8t.jpg"},
        {productId:"P104",productName:"Google pixel",description:"Google pixel 256gb, grey colour",price:50000,quantity:3,imageUrl:"images/googlePixel.jpg"}
    ]
      
    };
  }
  onCartDataToAppEventHandler=(cartObj)=>{
    // modify the quantity
    var tempObj={...this.state.productsArr.find(item => item.productId === cartObj.productId)};
    tempObj.quantity-=cartObj.quantitySelected;

    this.setState((prevState)=>{
        var pos=prevState.productsArr.findIndex(item => item.productId === cartObj.productId);
        prevState.productsArr[pos].quantity-=cartObj.quantitySelected;
        return {...prevState};
    })
    this.setState((prevState)=>{
      var pos=prevState.cartArr.findIndex(item => item.productId ===cartObj.productId)
      if(pos >=0)
      {
        prevState.cartArr[pos].quantitySelected+=cartObj.quantitySelected;
        return ({cartArr:prevState.cartArr});
      }
      return(
        {cartArr:[...prevState.cartArr,cartObj]}
      );
      },()=>{
      console.log("In App component",this.state.cartArr);
    });
  }
  render() {
    return (
      <React.Fragment>
        <Register></Register>
        
      </React.Fragment>
    );
  }
}



export default App;
// npx create-react-app first_project

/*
<Header></Header>
        <div className='container-fluid'>
          <div className='row'>
            <div className='col-1 offset-11'>
              {this.state.showCart
              ?
              <input type="button" className= "btn btn-primary" 
              value="Products" 
              onClick={()=>{this.setState({showCart:false})}} />

              :
              <input type="button" className= "btn btn-primary"  
              value="Cart" 
              onClick={()=>{this.setState({showCart:true})}} /> }
            </div>
          </div>
         
       </div>
        <div>
        {this.state.showCart 
        ?  <Cart cartArr={this.state.cartArr}></Cart>
        :  <ProductDisplay 
          productsArr={this.state.productsArr}
          onCartDataToApp={this.onCartDataToAppEventHandler}>
        </ProductDisplay>}
        </div>
       
        <Footer></Footer>
*/