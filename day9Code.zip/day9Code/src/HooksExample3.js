import React,{useRef,useEffect,useState} from 'react'

export default function useRefHookExample() {
    let [name,setName]=useState("");
    let userNameRef=useRef("");
    let lastNameRef=useRef({});
    useEffect(()=>{
    lastNameRef.current={lastName:"mehta"};

    },[name])
    const changeNameEventHandler=()=>{
        alert("Welcome "+ userNameRef.current.value);
        setName(userNameRef.current.value);

    }
    return (
        <div>
<input type="text" placeholder='Enter the first name' ref={userNameRef} />
            <input type="button" value="Change name" onClick={changeNameEventHandler} />
            <h1> First Name :{userNameRef.current.value}</h1>
            <h1> Last Name :{lastNameRef.current.lastName}</h1>
        </div>
    )
}


/*
useState -- hold the values across the renders
useRef -- persist the values across renders during the lifetime of the component
-- can point to an element
-- has to be intialised if interpolated
-- can hold a mutable object also which does not point to any element

createRef -persist the values across renders during the lifetime of the component
-- can point to an element
-- has to be intialised if interpolated


it is not compulsory that always ref should point to an element
*/


/*
useReducer
useDispatch
useSelector
useEffect -- after REAL DOM gets painted
useLayoutEffect -- before the DOM gets painted -- have some side effects executed



*/
/*
14-jan -- no training
17,18,19 jan -- 2 pm to 6 pm
20,21 jan -- 9 am to 1 pm 
other sessions 24jan -- 9 am to 1 pm

*/