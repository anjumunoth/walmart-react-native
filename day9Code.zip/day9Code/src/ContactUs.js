import React, { Component } from 'react'

export default class ContactUs extends Component {
    render() {
        return (
            <React.Fragment>
                <h1>ContactUs Component</h1>
                
            </React.Fragment>
        )
    }
}
