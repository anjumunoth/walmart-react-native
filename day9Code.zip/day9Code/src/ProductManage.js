import React, { Component } from 'react'
import {connect} from "react-redux";
import {deleteActionCreator,addActionCreator} from "./actions/actionCreators";

function mapStateToProps(state)
{
    // map redux store's state to component's props
    // the returned value will be stored as the component's props
    return {productsArr:state.productsArr};

}

function mapDispatchToProps(dispatch)
{
    // map redux's dispatch method 
    // whatever returned from this function gets added to the component's props
    return ({
        onDeleteConfirmation:(p1)=>{ return dispatch(deleteActionCreator(p1))},
        onAddProductConfirmation:(newProduct)=>{return dispatch(addActionCreator(newProduct))}
    })
}
class ProductManage extends Component {
   constructor(props)
   {
       super(props);
       this.state={productsArr:this.props.productsArr};
   }
   
   deleteProductEventHandler=(pId)=>{
       // trigger an event
       var p1={productId:pId}
       this.props.onDeleteConfirmation(p1);
       console.log("In delete handler",this.props)
       
   }
   addNewProductEventHandler=()=>{
       var pId=prompt("Enter the productId");
       var newProduct={productId:pId,productName:pId + "Name",description:"Apple mini 13 256gb, grey colour",price:10000,quantity:10,imageUrl:"images/iphone13Mini.jpg"};
       // dispatch an add product action 
        this.props.onAddProductConfirmation(newProduct);
        

   }
   editProductEventHandler=(selectedProduct)=>{
    this.props.history.push("/editProduct/"+selectedProduct.productId,{selectedProduct:selectedProduct})
   }
    render() {
        console.log("In Product Manage props :",this.props);
        let trArr=this.props.productsArr.map(item=>{
            return (
                <tr key={item.productId}>
                    <td>{item.productId}</td>
                    <td>{item.productName}</td>
                    <td>{item.price}</td>
                    <td>{item.quantity}</td>
                    <td>
                        <input type="button" value="Delete" className='btn btn-danger' onClick={this.deleteProductEventHandler.bind(this,item.productId)}/>
                        <input type="button" value="Edit" className='btn btn-danger' onClick={this.editProductEventHandler.bind(this,item)}/>
                    </td>
                </tr>
            );
        })
        return (
            <div>
                <table className='table'>
                    <thead>
                        <tr>
                            <th>ProductId</th>
                            <th>ProductName</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Actions </th>
                        </tr>
                    </thead>
                    <tbody>
                       {trArr}                        
                    </tbody>
                </table>
                <input type="button" value="Add New product" className='btn btn-primary' onClick={this.addNewProductEventHandler}/>
            </div>
        )
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(ProductManage)