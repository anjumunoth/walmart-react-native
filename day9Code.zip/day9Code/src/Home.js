import React, { Component } from 'react'
import { Route, Switch } from 'react-router-dom'
import AboutUs from './AboutUs'
import ContactUs from './ContactUs'
import Register from './Register'
import Details from './Details'
import Cart from './Cart'
import ProductDisplay from './ProductDisplay'
import ProductManage from './ProductManage'
import EditProduct from './EditProduct'
import Sample from './Sample'
import HooksExample1 from './HooksExample1'
import HooksExample2 from './HooksExample2'
import useRefHookExample from './HooksExample3'
import useReducerHookExample from './useReducerHookExample'

export default class Home extends Component {
    constructor()
  {
    super();
    this.state={
      showCart:false,
      cartArr:[],
      productsArr:[
        {productId:"P101",productName:"Apple 13 mini",description:"Apple mini 13 256gb, grey colour",price:85678,quantity:12,imageUrl:"images/iphone13Mini.jpg"},
        {productId:"P102",productName:"Samsung fold3",description:"Samsung fold3 256gb, grey colour",price:145678,quantity:7,imageUrl:"images/samsungFold3.jpg"},
        {productId:"P103",productName:"One plus 8t",description:"One plus 8t 256gb, grey colour",price:65678,quantity:5,imageUrl:"images/oneplus8t.jpg"},
        {productId:"P104",productName:"Google pixel",description:"Google pixel 256gb, grey colour",price:50000,quantity:3,imageUrl:"images/googlePixel.jpg"}
    ]
      
    };
  }
  onCartDataToAppEventHandler=(cartObj)=>{
    // modify the quantity
    var tempObj={...this.state.productsArr.find(item => item.productId === cartObj.productId)};
    tempObj.quantity-=cartObj.quantitySelected;

    this.setState((prevState)=>{
        var pos=prevState.productsArr.findIndex(item => item.productId === cartObj.productId);
        prevState.productsArr[pos].quantity-=cartObj.quantitySelected;
        return {...prevState};
    })
    this.setState((prevState)=>{
      var pos=prevState.cartArr.findIndex(item => item.productId ===cartObj.productId)
      if(pos >=0)
      {
        prevState.cartArr[pos].quantitySelected+=cartObj.quantitySelected;
        return ({cartArr:prevState.cartArr});
      }
      return(
        {cartArr:[...prevState.cartArr,cartObj]}
      );
      },()=>{
      console.log("In App component",this.state.cartArr);
    });
  }
    render() {
        return (
            <React.Fragment>
                <Switch>
                <Route path="/usereducer" component={useReducerHookExample}></Route>
                <Route path="/hooksExample3" component={useRefHookExample}></Route>
                <Route path="/hooksExample2" component={HooksExample2}></Route>
                  <Route path="/hooksExample1" component={HooksExample1}></Route>
                  <Route path="/time" component={Sample}/>
                  <Route path="/editProduct/:pId" component={EditProduct}></Route> 
                    <Route path="/cart" >
                        <Cart cartArr={this.state.cartArr}></Cart>
                    </Route>
                    <Route path="/products">
                        <ProductDisplay
                            productsArr={this.state.productsArr}
                            onCartDataToApp={this.onCartDataToAppEventHandler}>
                        </ProductDisplay>
                    </Route>
                    <Route path="/details/:pId" component={Details}></Route>

                    <Route path="/productmanage" component={ProductManage}></Route>
                    <Route path="/details" component={Details}></Route>
                    <Route path="/" exact component={Register}></Route>
                    <Route path="/aboutus" component={AboutUs}></Route>
                    <Route path="/contactus" component={ContactUs}></Route>
                    <Route path="/register" component={Register}></Route>
                    <Route render={() => { return (<div><h1>Page Not Found</h1></div>); }} ></Route>
                </Switch>
            </React.Fragment>
        )
    }
}


/*
11-1-2022 -- Redux
12-1-2022 -- Hooks and React native introduction
13-1-2022 -- React native -- core components
14-1-2022 -- holiday
*/