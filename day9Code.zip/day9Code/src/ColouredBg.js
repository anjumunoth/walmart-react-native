import React,{useState,useEffect} from 'react'

export default function ColouredBg(props) {
   
    const [likes,setLikes]=useState(0);
    useEffect(()=>{
        // getDerivedStateFromProps
        setLikes(0);
    },[props.selectedColour])

    const decLikes=()=>{
        setLikes(prevLikes => prevLikes -1);
    }
    const incLikes=()=>{
        setLikes(prevLikes => prevLikes +1);
    }
    return (
        <div>
            <h1> selected colour : {props.selectedColour}</h1>
            
            <input type="button" value = "-" onClick={decLikes}/>
            <h2> Likes :{likes}</h2>
            <input type="button" value = "+" onClick={incLikes}/>
        </div>
    )
}
