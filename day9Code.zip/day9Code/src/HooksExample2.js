import React,{useEffect,useState} from 'react'
import ColouredBg from './ColouredBg';

export default function HooksExample2() {
    let [ctr,setCtr]=useState(0);
    let [name,setName]=useState("asha");
    let [lastName,setLastName]=useState("mehta");
    let [emp,setEmp]=useState({empId:101,empName:"sara"});
    let [time,setTime]=useState((new Date().toLocaleTimeString()));
    let [colours,setColours]=useState(['green','blue','white']);
    let [selectedColour,setSelectedColour]=useState("green");

    useEffect(()=>{
        console.log("Effect 1 executed");
    },[])

    useEffect(()=>{
        console.log("Effect 2 executed");
    },[])
    /*  useEffect(()=>{
        
        var clearIntervalID=setInterval(()=>{
            setTime((new Date().toLocaleTimeString()));
        },10000);
        console.log("Set interval started with Id"+clearIntervalID);
        return( ()=>{
            // componentWillUnmount
            console.log("Set Interval cleared with the ID"+ clearIntervalID);
            clearInterval(clearIntervalID);
        })
    },[]); 
 */
    useEffect(()=>{
        console.log("Name based use effect called");
        setName(prevName => prevName.toLowerCase());
        setLastName(prevLastName => prevLastName.toLowerCase());
    },[name,lastName]);

    useEffect(()=>{
        console.log("Depenedency list with entire object called");
    },[emp])

    useEffect(()=>{
        console.log("Depenedency list with empName alone called");
    },[emp.empName])

    useEffect(()=>{
        console.log("Depenedency list with colours changed called");
    },[colours])

    useEffect(()=>{
        console.log("New use effect with return executed");
        return (()=>{
            console.log("clearing useEffect executed");
        })
    })

    useEffect(() => {
        console.log("Second use effect called since name changed")
      return () => {
       console.log("Second return of useEffect called whenever name changes");
      };
    }, [name])

    const nameChangeEventHandler=(e)=>{
        setName(e.target.value);
    }

    const lastNameChangeEventHandler=(e)=>{
        setLastName(e.target.value);
    }
    const incrementCtrEventHandler=()=>{
        //setCtr(ctr+1);
        setCtr((currentCtr)=>{return (currentCtr +1);})
    }
    const changeEmpObjectEventHandler=()=>{
        setEmp({empId:102,empName:"tara"});
    }

    const changeColourEventHandler=()=>{
        var rand= (parseInt(Math.random()*10))%3;
        alert(rand);
        alert(colours[rand]);
        setSelectedColour(colours[rand]);
    }
    return (
        <div>
            <h1> Use Effect Examples</h1>
            <input type="button" value="Increment ctr" onClick={incrementCtrEventHandler}/>
            <h1>Ctr : {ctr}</h1>
            <h1>Time : {time}</h1>
            <input type="text" onChange={nameChangeEventHandler}/>
            <input type="text" onChange={lastNameChangeEventHandler}/>
            
            <h1> Hello {name} {lastName}</h1>
            <input type="button" value="Change the entire emp object" onClick={changeEmpObjectEventHandler}/>
            <h1> My fav colours : {colours}</h1>
            <input type="button" value="Change a colour" onClick={changeColourEventHandler}/>
            <ColouredBg selectedColour={selectedColour}></ColouredBg>
        </div>
    )
}


/*
useEfect
1. useEffect only with one param:
    It will called after every render
    after Dom updation  useEffect will be executed 
    componentDidMount + componentDidUpdate

first rendering
    1. useState will get executed and initialised
    2. useEffect -- remember to execute after the render
    3. return the virtual DOM -- mapped to the real DOM
    4. execute the useEffects

second rendering:
1. useState -- give the value which it has stored across the render
2. useEffect -- replace the useEffect function
3. update the REAL Dom(return new Virtual dom -- diffing algo)
4. execute the useEffects

2. useEffect with 2 params, and second param is an empty dependency list:
 -- will be excuted only once
 -- compoenentDidMount

3. useEffect with 2 params, and second param is an dependency list:
-- whenever the dependency list changes, the effect will be executed

4. the returned function from a useEffect --is used to clean up resources or do the unsubscriptions


1. useState will be executed
2.useEffect -- reinitialised
3 REAL DOM manipulation dom's will happen
4. clearing of the previous useEffects will run
5. useEffects with new initialisations will run

setInterval -- executed only once
clearInterval -- only once 
useEffect(()=>{
        
        var clearIntervalID=setInterval(()=>{
            setTime((new Date().toLocaleTimeString()));
        },1000);
        console.log("Set interval started with Id"+clearIntervalID);
        return( ()=>{
            // componentWillUnmount
            console.log("Set Interval cleared");
            clearInterval(clearIntervalID);
        })
    },[]); 

useEffect with return 
1. empty dep list-- return work as componentWillUnMount but after render
2. no params  -- will be executed every time after render(both return and useEffect) 
3. values in the dep list -- 




    useEffect -- running after every render -- only one pass one param to useEffect 
    If the useEffect has a return  then what ?

    Real Dom updates will happen
    old useEffect has to be cleared
    current useEffect will be excuted



*/

/*
On mobile : App -- Expo Go
On laptop -- Mandatory -- Android studio -- Android simulator
If u want -- install XCode -- MacOs -- IOS simulator
*/