import React, { Component } from 'react'

export default class TestClass extends Component {
    constructor(props)
    {
        super(props);
        this.state={};
        this.onChangeEventHandler=this.onChangeEventHandler.bind(this);
    }
    onChangeEventHandler(){
        console.log(this.props);//error
    }
    
    render() {
        return (
            <div>
                <input type="button" onClick={this.onChangeEventHandler}/>
            </div>
        )
    }
}
