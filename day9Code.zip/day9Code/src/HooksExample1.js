import React,{useState} from 'react'

function HooksExample1(){
    /* let arr=useState("anju");
    let name=arr[0];
    let setName=arr[1];// used to set the value of name ; function
 */
    let [name,setName]=useState("guest");
    let [companyName,setCompanyName]=useState("walmart");
    let [ctr,setCtr]=useState(0);
    console.log("Return of a useState",useState("test"));
    //setName("anju");
    const incrementCtrEventHandler=()=>{
        //setCtr(ctr+1);
        setCtr((currentCtr)=>{return (currentCtr +1);})
    }
    const welcomeUserEventHandler=()=>{
        
        setEmp1({empId:100,empName:"harry"});
    }

    let [emp,setEmp]=useState({empId:101,empName:"sara",salary:5678});
    let [emp1,setEmp1]=useState();
    console.log("Emp1",emp1);
    //emp1 -- undefined
    const changeNameEventHandler=(event)=>{
        setName(event.target.value);//2 tasks --update the name ;--return the virtual DOM again
    }
    const changeCompanyNameEventHandler=(event)=>{
        setCompanyName(event.target.value);//2 tasks --update the name ;--return the virtual DOM again
    }
    
    // setState -- modify the state and call the render method implicitly
    return (
        <React.Fragment>
            <h1>Hooks Example</h1>
            <form>
                <input id="txtName" type="text" placeholder='Enter ur name' onChange={changeNameEventHandler}/>
                <input  type="text" placeholder='Enter ur company name' onChange={changeCompanyNameEventHandler}/>
                <input type="button" value="Welcome user" onClick={welcomeUserEventHandler}/>
                
            </form>
            <h1> Hello {name}</h1>
            <h2> Company Name : {companyName}</h2>
            <h2>Employee Details : {JSON.stringify(emp)}</h2>
            <h2>Employee Details2 : {JSON.stringify(emp1)}</h2>

            <input type="button" value="Increment ctr" onClick={incrementCtrEventHandler}/>
            <h1>Ctr : {ctr}</h1>
        </React.Fragment>
    );
}

export default HooksExample1;


/*

first time component is rendered --

useState("guest"); -- initialisation will work
return the virtual DOM

update and setState
1. start from the beginning of the function

useState will hold the data across multiple renders
useState() -- ignore the value in the initialisation and store the value which it has the preserved


setState in class component -- merge the object with the state
useState in functional component -- replace the value 

this.state={empId:101,empName:"sara",salary:6789}

this.setState({salary:1000},()=>{clg(this.state)});//{empId:101,empName:"sara",salary:1000}

const [emp,setEmp]=useState({empId:101,empName:"sara",salary:6789});

// in a eventhandler
setEmp({salary:1000})

{JSON.stringify(emp)};//{salary:1000}

let arr1=[10,20,30];
let resArr=arr1.map(item => item*item);

*/