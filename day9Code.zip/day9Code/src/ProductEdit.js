import React from 'react';
import ProductChildEdit from './ProductChildEdit';
import ProductChildEdit2 from './ProductChildEdit2';
class ProductEdit extends React.Component {

    constructor(props) {

        super(props);

        this.state = {

            products: [{ productId: "P101", productName: "Apple 13 mini", description: "Apple mini 13 256gb, grey colour", price: 85678, quantity: 12, imageUrl: "images/iphone13Mini.jpg" },

            { productId: "P102", productName: "Samsung", description: "Samsung 13 256gb, grey colour", price: 8567, quantity: 10, imageUrl: "images/iphone13Mini.jpg" },

            { productId: "P103", productName: "One Plus Series", description: "One Plus 13 256gb, grey colour", price: 85, quantity: 8, imageUrl: "images/iphone13Mini.jpg" },

            { productId: "P104", productName: "Lenovo Mobiles", description: "Lenovo 13 256gb, grey colour", price: 185678, quantity: 6, imageUrl: "images/iphone13Mini.jpg" },],

            showChild: false,

            selectedProduct: {}

        };

    };



    editEventHandlder = (productItem) => {

        this.setState({ selectedProduct: productItem, showChild: true });

    };



    render() {



        var productsArr = this.state.products.map((productItem) => {

            return (

                <tr>

                    <td>{productItem.productId}</td>

                    <td>{productItem.productName}</td>

                    <td>{productItem.price}</td>

                    <td>{productItem.quantity}</td>

                    <input type="button" className='btn btn-warning' value="edit" onClick={() => this.editEventHandlder(productItem)} />

                </tr>

            );

        });



        return (

            <React.Fragment>

                <table className='table'>

                    <thead>

                        <tr>

                            <th>Product Id</th>

                            <th>Product Name</th>

                            <th>Price</th>

                            <th>Quantity</th>

                        </tr>

                    </thead>

                    <tbody>

                        {productsArr}

                    </tbody>

                </table>

                {this.state.showChild && <ProductChildEdit2 selectedProduct={this.state.selectedProduct}></ProductChildEdit2>}

            </React.Fragment>

        );

    };

}



export default ProductEdit;