import React from 'react';
import { Link } from 'react-router-dom';
import "./Menu.css";

export default class Menu extends React.Component {
    render() {
        return (
            <div>
                <ul id="ulMenuHeader">
                    <li className='liMenuItem'>
                       <Link to="/aboutus">About Us</Link>
                    </li>
                    <li className='liMenuItem'>
                        <Link to="/contactus">Contact Us</Link>
                    </li>
                    <li className='liMenuItem'>
                        <Link to="/register">Register</Link>
                    </li>
                    <li className='liMenuItem'>
                        <Link to="/details/101">Details</Link>
                    </li>
                    <li className='liMenuItem'>
                        <Link to="/products">Products</Link>
                    </li>
                    <li className='liMenuItem'>
                        <Link to="/cart">Cart</Link>
                    </li>
                    <li className='liMenuItem'>
                        <Link to="/productmanage">Product Manage</Link>
                    </li> 
                    <li className='liMenuItem'>
                        <Link to="/hooksExample1">Hooks Example1</Link>
                    </li>
                    <li className='liMenuItem'>
                        <Link to="/hooksExample2">Hooks Example2</Link>
                    </li>
                    <li className='liMenuItem'>
                        <Link to="/hooksExample3">Hooks Example3</Link>
                    </li>
                    <li className='liMenuItem'>
                        <Link to="/useReducer">Use Reducer Example</Link>
                    </li>             
                </ul>
            </div>
        )
    }
}
