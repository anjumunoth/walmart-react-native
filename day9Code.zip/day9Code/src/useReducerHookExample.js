import React,{useReducer} from 'react'

const initialState={todoArr:[]};
function todoReducer(state,action){
    let newState={...state,todoArr:[...state.todoArr]};
    switch(action.type)
    {
        case "ADD_TODO":
            newState.todoArr=[...newState.todoArr,action.payload];
            break;
        case "DEL_TODO":break;
        case "UP_TODO":break;
    }
    return newState;

}
export default function useReducerHookExample() {
    const [state,dispatch]=useReducer(todoReducer,initialState);// works similar to useState()
    
    const addTodoEventHandler=()=>{
        var newTask=prompt("Enter the todo task");
        dispatch({type:"ADD_TODO",payload:newTask})
    }
    return (
        <div>
            <ul>
                {
                    state.todoArr.map(item =>{
                        return(
                            <li>{item}</li>
                        )
                    })
                }

            </ul>
            <input type="button" value="Add Todo" onClick={addTodoEventHandler}/>
        </div>
    )
}

/*
reducer in redux -- pure function which will change the state
 -- returns a new state
 -- dispatch an action -- implicitly call the reducer
 -- centralised management of data(single source)
 -- complex data -- manage , share it among diff components
 -- reducer -- immutability of the state

 like a redux store for a particular component
 -- when the state is complex -- need not have multiple states
 -- immutablilty -- reducer is very easy
 -- local state of component
 -- persist the value across render 

 projectArr:[projectId,projectName, empIdArr:]// only those emp working in each project
 empArr: all the emp working in the company

 add a new emp for a particular project -- 

 change in the projectArr
 change in empArr

 only state -- have 2 setState calls -- 2 renders - there may be a chance that i forget one update
 only reducer -- dispatch only 1 action  -- set both the arrays -- 2 renders sync updates  

 UI
 projectID, projectName, empName

 
*/
