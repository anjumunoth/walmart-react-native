import * as yup from "yup";


const userNameValidation=yup
.string()
.required("Username is required")
.min(8,"Username should be minimum 8 characters long");

const passwordValidation=yup
.string()
.required("Password is mandatory")
.min(8,"Password should be min 8 characters")
.max(15,"Password should be max 8 characters")
.matches(/\w*[a-z]\w*/,"Password should have a lowercase char")
.matches(/\w*[A-Z]\w*/,"Password should have a uppercase char")
.matches(/\d/,"Password should have a number")
.matches(/[!@#$%^&*(){}":<>?/.,]/,"Password should have a special char");

const confirmPasswordValidation =yup
.string()
.required("Confirm Password is required")
.when("password",
{
    is:(value)=>(value && value.length>8 ? true: false),
    then:yup.string().oneOf([yup.ref("password")],"Password and confirm password do not match")
}
);

const employeeIdValidation=yup
.string()
.required("EmployeeId is mandatory")
.test("isEmployeeIdStartingWithW","Employee Id should start with W",
(value)=>(value && value.startsWith("W"))
)

export default validationSchema= yup.object().shape({
    userName:userNameValidation,

    password: passwordValidation,

    confirmPassword:confirmPasswordValidation,

    employeeId:employeeIdValidation
})