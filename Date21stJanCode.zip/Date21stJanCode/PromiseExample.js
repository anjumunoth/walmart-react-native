function myFunc(p1)
{
    var res=setInterval(()=>{
        // talk with the server
        return p1*p1;
    },1000);

    console.log("bye");
    return res;
}

var output=myFunc(100);
console.log(output);// integer value like 1 or 2

function myFunc2(p1)
{
    return Promise.resolve(p1*p1);
}

myFunc2(100)
.then((data)=>{ console.log(data);})
.catch((err)=>{console.log(error);})
console.log(res);//

function myFunc3(p1)
{
    const myPromise=new Promise((resolve,reject)=>{
        setInterval(()=>{
            if(p1 %2 ==0)
            {
                resolve(p1*p1)
            }
            else
            {
                reject(`${p1} is not an even number`);
            }

        },1000)
       
    })
    
    return myPromise;
}

myFunc3(100)
.then((data)=>{console.log("Data from async op "+ data);})
.catch((err)=>{console.log("Error :"+err);})


myFunc3(200)
.then((data)=>{
    // return some value --return a new Promise which also has resolved with data*data 
    return data*data})
.then((newData)=>{console.log("newData"+newData);})
.catch((err)=>{return err+". Please enter only even numbers"})
.catch((updatedErrMsg)=>{console.log(updatedErrMsg);})


myFunc3(201)
.then((data)=>{
    // return some value --return a new Promise which also has resolved with data*data 
    return data*data})
.then((newData)=>{console.log("newData"+newData);})
.catch((err)=>{return err+". Please enter only even numbers"})
.catch((updatedErrMsg)=>{console.log(updatedErrMsg);})

// newData=40000*40000
/*
Promise -- proxy of value of a async function
Async operation 
-- be successful -- return value
-- fail -- reason why it has failed

Promise - 3 stages:
1.pending -- initial state ; async op is evaluating
2. fulfilled state -- async op is successful
3. rejected state -- async op has failed


async and await
function which return a promise -- can use await 
Rule -- await should always be used inside another async fn

async function myFunc4()
{
    try
    {
var output=await myFunc3(200);
console.log("Output"+output);//40000
var output=await myFunc3(10);
console.log("Output"+output);//100

console.log("bye");
    }
    catch(err)
    {
        console.log("Error",err)
    }
}


async operation
3 ways in js
  -- callback
  -- promises
  -- async await

  setState(obj/function,callback function)
  fetch -- promises
  
*/