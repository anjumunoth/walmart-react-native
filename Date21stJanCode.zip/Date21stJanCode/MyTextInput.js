import React from 'react';
import { View, Text, TextInput,StyleSheet } from 'react-native';

export default function MyTextInput(props) {
  return (
    <View>
      <TextInput {...props} style={[styles.textBox,{...props.style}]} ></TextInput>
     </View>
  );
}

const styles=StyleSheet.create(
    {
        textBox:{
            backgroundColor:"white",
            color:"blue",
            borderWidth:5,
            borderColor:"black",
            borderRadius:10,
            height:50,
            width:200,
            padding:10,
            
            
        }
    }
)
