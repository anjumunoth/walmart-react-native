import { StyleSheet, Text, View } from 'react-native';
import React from 'react';

const MyErrorMessage = (props) => {
    const {errors,touched,style,fieldName}=props;
    return (
        <View>
            <Text style="[styles.errorMessageText,{...style}]" >
                {
                    errors[fieldName] && touched[fieldName] ? errors[fieldName] : null
                }
            </Text>

        </View>
    );
};

export default MyErrorMessage;

const styles = StyleSheet.create({
    errorMessageText: {
        color: "red",
        fontSize: 18
    }
});
