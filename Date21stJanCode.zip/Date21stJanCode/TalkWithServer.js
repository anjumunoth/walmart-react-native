import { FlatList, StyleSheet, Text, View,ActivityIndicator,Platform, SafeAreaView } from 'react-native';
import React,{useState,useEffect} from 'react';

const TalkWithServer = () => {
const[isLoading,setIsLoading]=useState(true)
const [data,setData]=useState([]);
const [errorMessage,setErrorMessage]=useState("");
useEffect(()=>{
    var serverUrl="https://jsonplaceholder.typicode.com/users";
    // send a GET request to the serverUrl
    fetch(serverUrl)
    .then((res)=>{
        return res.json();
        
    })
    .then((resJson)=>{
        console.log("Response from the server",resJson);
        setData(resJson);
        setIsLoading(false);
    })
    .catch((err)=>{
        console.log("Error",err);
        setErrorMessage(err);
    })
},[])
const renderItem=(props)=>{
    if(Platform.OS==='android')
    {
    return (
        <View>
            <Text style={{color:"blue"}}>Name : {props.item.name}</Text>
            <Text style={{color:"blue"}}>Email : {props.item.email}</Text>
        </View>
    )
    }
    else
    if(Platform.OS==='ios')
    {
        return (
            <SafeAreaView>
                <Text>Name : {props.item.name}</Text>
                <Text>Email : {props.item.email}</Text>
            </SafeAreaView>
        ) 
    }

}
const itemSeperator=()=>{
    return (
        <View style={styles.itemSeperator}></View>
    )
}
  return (
    <View style={styles.container}>
      <Text style={styles.header}> Talk with server</Text>
      <ActivityIndicator animating={isLoading} color="red" size={"large"}></ActivityIndicator>
      <View>
          <FlatList 
          data={data}
          renderItem={renderItem}
          keyExtractor={item=> item.id.toString()}
          ItemSeparatorComponent={itemSeperator}
          ></FlatList>
      </View>
      <Text style={styles.errText}>
          {errorMessage.length>0 ?errorMessage:null}
      </Text>
    </View>
  );
};

export default TalkWithServer;

const styles = StyleSheet.create({
    container:{
        flex:1,
        backgroundColor:"pink",
        margin:40,
        width:"100%"
    },
    errText:{
        color:"red"
    },
    itemSeperator:{
        height:5,
        margin:3,
        width:"100%",
        backgroundColor:Platform.OS ==='ios'?"black":"green"
    },
    header:
    {
        color:"blue",
        fontSize:32,
        fontWeight:"bold",
        textAlign:"center"
    }
});

/*
class component -- componentDidMount -- requests to the server
functional component -- execute only once -- second param as empty depenedency list; request as part of useEffect


*/

/*
Core components
Forms -- login,register
Validations
Post data 
get data
Work with data -- redux ; persist -- async storage
offline
navigation -- navigate 
authentication/ authorisation

push notifications
publish appstore/playstore

expenses tracker -- 





mobile's native -- camera,geo location


*/
