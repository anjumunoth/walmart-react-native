import { Button, StyleSheet, Text, View,ScrollView } from 'react-native';
import { Formik } from "formik"
import React from 'react';
import MyTextInput from './MyTextInput';
import * as yup from "yup";
import validationSchema from "./YupValidations";
import MyErrorMessage from './MyErrorMessage';


const FormikExample = () => {

    return (
        <ScrollView style={styles.container} contentContainerStyle={{alignItems:"center"}}>
            <View>
                <Text style={styles.headerText} >Register</Text>
            </View>
            <Formik style={styles.formikConatiner}
                initialValues={{ userName: "", password: "", confirmPassword: "", employeeId: "" }}
                onSubmit={values => console.log(values)}
                validationSchema={validationSchema}
            >
                {({ handleChange, handleSubmit, values, errors, isValid, touched, handleBlur }) => {
                    return (
                        <View>
                            <View>
                                <MyTextInput
                                    placeholder="Enter the username"
                                    onChangeText={handleChange('userName')}
                                    value={values.userName}
                                    onBlur={handleBlur('userName')}

                                ></MyTextInput>

                                <MyErrorMessage fieldName="userName" errors={errors} touched={touched}></MyErrorMessage>

                            </View>
                            <View>
                                <MyTextInput
                                    value={values.password}
                                    placeholder="Enter the password"
                                    onChangeText={handleChange('password')}
                                    secureTextEntry
                                    onBlur={handleBlur('password')}
                                ></MyTextInput>
                                <MyErrorMessage fieldName="password" errors={errors} touched={touched}></MyErrorMessage>
                            </View>
                            <View>
                                <MyTextInput
                                    value={values.confirmPassword}
                                    placeholder="Enter the confirm password"
                                    onChangeText={handleChange('confirmPassword')}
                                    onBlur={handleBlur('confirmPassword')}
                                ></MyTextInput>
                                <MyErrorMessage fieldName="confirmPassword" errors={errors} touched={touched}></MyErrorMessage>
                            </View>
                            <View>
                                <MyTextInput
                                    value={values.employeeId}
                                    placeholder="Enter the Employee Id"
                                    onChangeText={handleChange('employeeId')}
                                    onBlur={handleBlur('employeeId')}
                                ></MyTextInput>
                                <MyErrorMessage fieldName="employeeId" errors={errors} touched={touched}></MyErrorMessage>
                            </View>

                            <Button title="Register" onPress={handleSubmit} disabled={!isValid} />

                        </View>
                    )
                }}
            </Formik>
        </ScrollView>
    );
};

export default FormikExample;

const styles = StyleSheet.create({
    container: {
        backgroundColor: "pink",
        marginTop: 40,
      
        width:"90%",
        
    },
    formikConatiner:
    {width:"90%"},
    headerText:{
        fontSize:36,
        
    }

});


// Username -- required; length
// Password -- required;strong password
// Confirm Password -- required; must match with password; password should validate
// mobile number -- required; can only consist of 10 numbers, (),+
// email -- required, email format
// employeeId -- required, must start with W; should already exists-- onBlur;



// string password -- min 8 char ; max 15 char; contain Uc, Lc, number and special character



//Notes of errors -- red

// Below each control display the corresponding error messages

//touched -- control -- validations fail -- display errors

// Initially disable -- Register
// Register enabled -- validations pass

// submit the form -- send it to server as a post request