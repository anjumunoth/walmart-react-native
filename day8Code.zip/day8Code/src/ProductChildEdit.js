import React from "react";
class ProductChildEdit extends React.Component {
    constructor(props)
    {
        super(props);
        this.state={productName:"",quantity:"",productId:this.props.selectedProduct.productId};
        this.priceRef=React.createRef();
    }
    
    saveEventHandler=()=>{
        console.log("Ref of input element whicl holds the price value",this.priceRef);
        console.log("Changed product details");
        console.log("New product Id"+ this.state.productId);
        console.log("New product Name"+ this.state.productName);
        console.log("New price"+ this.priceRef.current.value);

    }
    quantityChangeEventHandler=(event)=>{
        console.log("Inside change of quantity");
        this.setState({quantity:event.target.value})
    }
    productNameChangeEventHandler=(event)=>{
        if(event.target.value.indexOf("mobile") >=0)
        {
            this.setState({productName:event.target.value})
        }
        else
        {
            console.log("Product name should consist the mobile keyword")
        }
        
    }
    productIdChangeEventHandler=(event)=>{
        this.setState({productId:event.target.value});
    }
    render() {
        var selectedProduct = {...this.props.selectedProduct};
        return (

            <React.Fragment>
                <div >
                    <h1> Edit Product Details</h1>
                </div>
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-4 offset-4">
                        <form>
                        <div className='mb-3'>
                            <label className='form-label'>Product Id</label>
                            <input type="text" 
                            value={this.state.productId} 
                            onChange={this.productIdChangeEventHandler} />

                        </div>
                        <div className='mb-3'>
                            <label className='form-label'>Product Name</label>
                            <input type="text" className='form-control' 
                                defaultValue={selectedProduct.productName}
                                onChange={this.productNameChangeEventHandler}/>
                        </div>
                        <div className='mb-3'>
                            <label className='form-label'>Price</label>
                            <input type="text" className='form-control' 
                                defaultValue={selectedProduct.price}
                                ref={this.priceRef}
                                />
                        </div>
                        <div className='mb-3'>
                            <label className='form-label'>Quantity</label>
                            <input type="text" className='form-control' 
                            value={selectedProduct.quantity} 
                            onChange={this.quantityChangeEventHandler}
                            />
                        </div>
                        <div className="mb-3">
                            <input type="button" value="Save" onClick={this.saveEventHandler} />
                        </div>
                    </form>

                        </div>
                    </div>
                   


                </div>

            </React.Fragment>

        );

    }

};



export default ProductChildEdit;