import React,{useState} from 'react'

function HooksExample1(){
    /* let arr=useState("anju");
    let name=arr[0];
    let setName=arr[1];// used to set the value of name ; function
 */
    let [name,setName]=useState("guest");
    let [companyName,setCompanyName]=useState("walmart");
    console.log("Return of a useState",useState("test"));
    setName("anju");

    const welcomeUserEventHandler=()=>{
        
        setEmp1({empId:100,empName:"harry"});
    }

    let [emp,setEmp]=useState({empId:101,empName:"sara",salary:5678});
    let [emp1,setEmp1]=useState();
    console.log("Emp1",emp1);
    //emp1 -- undefined
    const changeNameEventHandler=(event)=>{
        setName(event.target.value);//2 tasks --update the name ;--return the virtual DOM again
    }
    const changeCompanyNameEventHandler=(event)=>{
        setCompanyName(event.target.value);//2 tasks --update the name ;--return the virtual DOM again
    }
    
    // setState -- modify the state and call the render method implicitly
    return (
        <React.Fragment>
            <h1>Hooks Example</h1>
            <form>
                <input id="txtName" type="text" placeholder='Enter ur name' onChange={changeNameEventHandler}/>
                <input  type="text" placeholder='Enter ur company name' onChange={changeCompanyNameEventHandler}/>
                <input type="button" value="Welcome user" onClick={welcomeUserEventHandler}/>
                
            </form>
            <h1> Hello {name}</h1>
            <h2> Company Name : {companyName}</h2>
            <h2>Employee Details : {JSON.stringify(emp)}</h2>
            <h2>Employee Details2 : {JSON.stringify(emp1)}</h2>
        </React.Fragment>
    );
}

export default HooksExample1;