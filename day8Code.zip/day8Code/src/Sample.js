import React, { Component } from 'react'

export default class Sample extends Component {
    constructor(props) {
        super(props);
        this.state = {data:"", time: new Date().toLocaleTimeString(), clearIntervalId: "" };
    }
    componentDidMount() {
        var clearIntervalId = setInterval(() => {
            this.setState({ time: new Date().toLocaleTimeString() })
        }, 1000);
        this.setState({ clearIntervalId: clearIntervalId });

        fetch('https://jsonplaceholder.typicode.com/todos/1')
            .then(response => response.json())
            .then(json => {
                console.log(json); 
                this.setState({ data: json });
    })
}
componentWillUnmount()
{
    clearInterval(this.state.clearIntervalId);
    alert("Interval cleared");
}
render() {
    return (
        <div>
            <h1>{this.state.time}</h1>
            <h2>{JSON.stringify(this.state.data)}</h2>
        </div>
    )
}
}

