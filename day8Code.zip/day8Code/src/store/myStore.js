import {createStore} from "redux";
import productReducer from "../reducers/productReducer";
var  productsArr=[
    {productId:"P101",productName:"Apple 13 mini",description:"Apple mini 13 256gb, grey colour",price:85678,quantity:12,imageUrl:"images/iphone13Mini.jpg"},
    {productId:"P102",productName:"Samsung fold3",description:"Samsung fold3 256gb, grey colour",price:145678,quantity:7,imageUrl:"images/samsungFold3.jpg"},
    {productId:"P103",productName:"One plus 8t",description:"One plus 8t 256gb, grey colour",price:65678,quantity:5,imageUrl:"images/oneplus8t.jpg"},
    {productId:"P104",productName:"Google pixel",description:"Google pixel 256gb, grey colour",price:50000,quantity:3,imageUrl:"images/googlePixel.jpg"}
]
var store=createStore(productReducer,{productsArr:productsArr});

export default store;