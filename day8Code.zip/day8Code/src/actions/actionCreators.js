export function addActionCreator(p1)
{
  return {type:"ADD_PRODUCT",payload:p1};
}

export function deleteActionCreator(p1)
{
  return {type:"DELETE_PRODUCT",payload:p1};
}

export function updateActionCreator(p1)
{
  return {type:"UPDATE_PRODUCT",payload:p1};
}

