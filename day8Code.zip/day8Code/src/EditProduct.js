import React, { Component } from 'react'
import { updateActionCreator } from "./actions/actionCreators";

import { connect } from "react-redux";

function mapDispatchToProps(dispatch) {
    return ({
        onUpdateAction: (p1) => { return dispatch(updateActionCreator(p1)) }
    })
}
class EditProduct extends Component {
    constructor(props) {
        super(props);
        this.state = { productName: "", quantity: "", productId: this.props.match.params.pId, selectedProduct: this.props.location.state.selectedProduct };
        this.priceRef = React.createRef();
    }

    saveEventHandler = () => {
        console.log("Ref of input element whicl holds the price value", this.priceRef);
        console.log("Changed product details");
        console.log("New product Id" + this.state.productId);
        console.log("New product Name" + this.state.productName);
        console.log("New Quantity" + this.state.quantity);
        console.log("New price" + this.priceRef.current.value);
        var updateProduct = {
            productId: this.state.productId, productName: this.state.productName,
            description: "Apple mini 13 256gb, grey colour",
            price: this.priceRef.current.value, quantity: this.state.quantity, imageUrl: "images/iphone13Mini.jpg"
        };
        this.props.onUpdateAction(updateProduct);
        this.props.history.push("/productmanage");
    }
    quantityChangeEventHandler = (event) => {
        console.log("Inside change of quantity");
        this.setState({ quantity: event.target.value })
    }
    productNameChangeEventHandler = (event) => {
        this.setState({ productName: event.target.value })


    }

    render() {
        var selectedProduct = { ...this.props.location.state.selectedProduct };
        return (

            <React.Fragment>
                <div >
                    <h1> Edit Product Details</h1>
                </div>
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-4 offset-4">
                            <form>
                                <div className='mb-3'>
                                    <label className='form-label'>Product Id</label>
                                    <label >{this.state.productId}</label>

                                </div>
                                <div className='mb-3'>
                                    <label className='form-label'>Product Name</label>
                                    <input type="text" className='form-control'
                                        defaultValue={selectedProduct.productName}
                                        onChange={this.productNameChangeEventHandler} />
                                </div>
                                <div className='mb-3'>
                                    <label className='form-label'>Price</label>
                                    <input type="text" className='form-control'
                                        defaultValue={selectedProduct.price}
                                        ref={this.priceRef}
                                    />
                                </div>
                                <div className='mb-3'>
                                    <label className='form-label'>Quantity</label>
                                    <input type="text" className='form-control'
                                        defaultValue={selectedProduct.quantity}
                                        onChange={this.quantityChangeEventHandler}
                                    />
                                </div>
                                <div className="mb-3">
                                    <input type="button" value="Save" onClick={this.saveEventHandler} />
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
};
export default connect(null, mapDispatchToProps)(EditProduct);