import React, { useEffect, useState } from 'react'
import { StyleSheet, Text,TextInput, TouchableOpacity, View, FlatList, Alert } from 'react-native'
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import AddExpense from "./AddExpense"
import OpenModal from './OpenModal';
import DateTimePicker from '@react-native-community/datetimepicker';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';

import clientApiObj from "../api/expenseApi";

export default function ExpenseDisplay() {
    
    const initialExpenseArr = [
        { expenseId: 1, expenseTitle: "title1", description: "description1", amount: 1234, paymentStatus: "true", category: "General", expenseDate: new Date() },
        { expenseId: 2, expenseTitle: "title2", description: "description2", amount: 1234, paymentStatus: "true", category: "General", expenseDate: new Date() },
        { expenseId: 3, expenseTitle: "title3", description: "description3", amount: 1234, paymentStatus: "true", category: "General", expenseDate: new Date() },
        { expenseId: 4, expenseTitle: "title4", description: "description4", amount: 1234, paymentStatus: "true", category: "General", expenseDate: new Date() },
        { expenseId: 5, expenseTitle: "title5", description: "description5", amount: 1234, paymentStatus: "true", category: "General", expenseDate: new Date() },
    ]
    const [expenseArr, setExpenseArr] = useState([]);
    const [showAddExpense,setShowAddExpense]=useState(false);

    async function fetchDetails(){
        var res=await clientApiObj.getExpenses();
        setExpenseArr(res);


    }
    //componentDidMount
    useEffect(()=>{
        fetchDetails();
    },[]);

    const onHideModalEventHandler=()=>{setShowAddExpense(false);}
    return (
        <View style={styles.body}>
            <View style={styles.headerView}>
                <Text style={styles.headerText}>
                    My Expense Tracker
                </Text>
            </View>
            <FlatList
                data={expenseArr}
                renderItem={({ item }) => (
                    <TouchableOpacity
                        style={styles.item}
                        onPress={() => {

                        }}
                    >
                        <View style={styles.card}>
                            <View style={styles.left} >

                                <View style={styles.firstRow}>
                                    <View style={[styles.expenseDate]}>
                                        <Text style={[styles.subtitle, { color: "yellow" }]}>
                                            {new Date(item.expenseDate).toLocaleDateString()}
                                        </Text>
                                    </View>
                                    <View style={[styles.expenseAmount]}>
                                        <Text style={[styles.subtitle, , { color: "red" }]}>
                                            Rs.  {item.amount}
                                        </Text>
                                    </View>
                                </View>

                                <View style={styles.secondRow}>
                                    <Text
                                        style={[styles.title]}
                                    >
                                        {item.expenseTitle}
                                    </Text>
                                    <Text
                                        style={[styles.subtitle]}
                                    >
                                        {item.description}
                                    </Text>
                                </View>

                                <View style={styles.thirdRow}>
                                    <Text
                                        style={[styles.subtitle]}
                                    >
                                        {item.category}
                                    </Text>

                                </View>

                            </View>
                            <View style={styles.right}>
                                <TouchableOpacity
                                    style={styles.delete}
                                    onPress={() => { }}
                                >
                                    <FontAwesome5
                                        name={'trash'}
                                        size={25}
                                        color={'#ff3636'}
                                    />
                                </TouchableOpacity>

                            </View>
                        </View>
                    </TouchableOpacity>
                )}
                keyExtractor={(item, index) => item.expenseId.toString()}
            />
            <TouchableOpacity
                style={styles.button}
                onPress={() => {
                    setShowAddExpense(true)
                }}
            >
                <FontAwesome5
                    name={'plus'}
                    size={20}
                    color={'#ffffff'}
                />
            </TouchableOpacity>
            {showAddExpense &&<OpenModal onHideModal={onHideModalEventHandler}></OpenModal>}
        </View>
    )
}

const styles = StyleSheet.create({
    body: {
        flex: 1,
        height: "100%",
        width: "100%"
    },
    headerText:{color:"blue",fontSize:32,fontWeight:"bold",textAlign:"center"},
    headerView:{
        backgroundColor:"cyan",
        borderWidth:5,
        borderColor:"blue",
        borderRadius:10
        
    },
    button: {
        width: 60,
        height: 60,
        borderRadius: 30,
        backgroundColor: '#0080ff',
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        bottom: 10,
        right: 10,
        elevation: 5,
    },
    secondRow: {
        flexDirection: 'column',
        alignItems: 'center',
    },
    firstRow: {
        flex: 1,
        flexDirection: "row",
        alignItems: "flex-start"
    },
    thirdRow: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    card: {
        flexDirection: 'row',
        justifyContent: "space-between"
    },
    left: {
        flex: 5
    },
    right: {
        flex: 1,
        justifyContent: "center",
        alignItems: 'center',
    },
    item_body: {
        flex: 1,
    },
    expenseDate: {
        backgroundColor: "grey",
        flex: 2,
        fontSize: 18,
        justifyContent: "space-between"
    },
    expenseAmount: {
        flex: 3,
        textAlign: "center",
        justifyContent: "space-between"
    },
    delete: {
        width: 50,
        height: 50,
        justifyContent: 'center',
        alignItems: 'center',
    },
    item: {
        marginHorizontal: 10,
        marginVertical: 7,
        paddingRight: 10,
        backgroundColor: '#ffffff',
        justifyContent: 'center',
        borderRadius: 10,
        elevation: 5,
    },
    title: {
        color: '#000000',
        fontSize: 30,
        margin: 5,
    },
    subtitle: {
        color: '#999999',
        fontSize: 20,
        margin: 5,
    },
    color: {
        width: 20,
        height: 100,
        borderTopLeftRadius: 10,
        borderBottomLeftRadius: 10,
    }
})
