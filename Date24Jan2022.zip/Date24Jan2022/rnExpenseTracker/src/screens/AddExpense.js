import { Pressable,StyleSheet, Text, View, TextInput, TouchableOpacity } from 'react-native';
import React, { useState, useRef } from 'react';
import { Picker } from '@react-native-picker/picker';
import DateTimePicker from '@react-native-community/datetimepicker';

const AddExpense = () => {
    const [expenseTitle, setExpenseTitle] = useState("");
    const [description, setDescription] = useState("")
    const [amount, setAmount] = useState("")
    const [selectedCategory, setSelectedCategory] = useState("General");
    const pickerRef = useRef();
    const [categories, setCategories] = useState(["General", "Grocery", "Education", "Food", "Travel"])
    const [expenseDate, setExpenseDate] = useState(new Date());
    const [displaymode, setMode] = useState('date');
    const changeSelectedDate = (event, selectedDate) => {
        const currentDate = selectedDate || expenseDate;
        setExpenseDate(currentDate);
        setShowDateTimePicker(false);
    };
    const [showDateTimePicker, setShowDateTimePicker] = useState(false);
    return (
        <View>
            <View style={styles.headerView}>
                <Text style={styles.headerText}>
                    Add Expenses
                </Text>
            </View>
            
            <TextInput
                value={expenseTitle}
                style={styles.input}
                placeholder='Title'
                onChangeText={(value) => setExpenseTitle(value)}
            />
            <TextInput
                value={description}
                style={styles.input}
                placeholder='Description'
                onChangeText={(value) => setdescription(value)}
            />
            <TextInput
                value={amount}
                style={styles.input}
                placeholder='Amount'
                onChangeText={(value) => setAmount(value)}
            />
            <Picker
                ref={pickerRef}
                selectedValue={selectedCategory}
                onValueChange={(itemValue, itemIndex) =>
                    setSelectedCategory(itemValue)

                }
                style={styles.pickerCustomeStyle}>
                {
                    categories.map((item,index) => {
                        return (
                            <Picker.Item key={index} label={item} value={item} style={{ color: "green" }} />
                        )
                    })
                }

            </Picker>
               <View>
                <Pressable onPress={() => setShowDateTimePicker(true)}>
                    <Text style={styles.input} >{expenseDate.toLocaleDateString()}</Text>
                </Pressable>
                    {showDateTimePicker &&
                        <DateTimePicker
                            testID="dateTimePicker"
                            value={expenseDate}
                            mode={displaymode}
                            is24Hour={true}
                            display="spinner"
                            onChange={changeSelectedDate}

                        />
                    }
                </View>
                <Pressable
                        style={[styles.button, styles.buttonClose,{margin:10}]}
                        onPress={() => {   }
                        }
                    >
                        <Text style={styles.textStyle}>Save Expense</Text>
                    </Pressable>

        </View>
    );
};

export default AddExpense;

const styles = StyleSheet.create({
    input: {
        width: '90%',
        borderWidth: 1,
        borderColor: '#555555',
        borderRadius: 10,
        backgroundColor: '#ffffff',
        textAlign: 'left',
        fontSize: 20,
        margin: 10,
        paddingHorizontal: 10,
    },
    text: {
        fontSize: 20,
        color: '#000000',
    },
    pickerCustomeStyle: {
        height: 50,
        color: "green",
        justifyContent: "center",
        backgroundColor: "white",
        width: '90%',
        borderWidth: 1,
        borderColor: '#555555',
        borderRadius: 10,
        backgroundColor: '#ffffff',
        textAlign: 'left',
        fontSize: 20,
        margin: 10,
        paddingHorizontal: 10,
    },
    button: {
        borderRadius: 20,
        padding: 10,
        elevation: 2,
        
    },
    buttonClose: {
        backgroundColor: "#2196F3",
        
    },
    textStyle: {
        color: "white",
        fontWeight: "bold",
        textAlign: "center"
    },
    headerText:{color:"blue",fontSize:32,fontWeight:"bold",textAlign:"center"},
    headerView:{
        backgroundColor:"cyan",
        borderWidth:5,
        borderColor:"blue",
        borderRadius:10
        
    },
});
