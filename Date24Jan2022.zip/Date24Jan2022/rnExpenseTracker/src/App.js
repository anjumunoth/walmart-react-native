/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React from 'react';
import {
  
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  useColorScheme,
  View,
  TouchableOpacity,
  Alert
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';

import {
  Colors,
  
} from 'react-native/Libraries/NewAppScreen';

import ExpenseDisplay from './screens/expenseDisplay';


const App= () => {
  const android_icon = (
    <Icon
      name="android"
      size={50}
      color="#007c00"
      onPress={() => { Alert.alert("Android Icon Clicked") }}
    />
  );
  const isDarkMode = useColorScheme() === 'dark';

  const backgroundStyle = {
    backgroundColor: isDarkMode ? Colors.darker : Colors.lighter,
  };

  return (
    
      <View style={styles.container}>
      <StatusBar barStyle={isDarkMode ? 'light-content' : 'dark-content'} />
            <ExpenseDisplay></ExpenseDisplay>
      </View>
    
  );
};

const styles = StyleSheet.create({
  container: {
    marginTop: 42,
   flex:1,
   height:"100%",
        width:"100%"
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: '600',
  },
  sectionDescription: {
    marginTop: 8,
    fontSize: 18,
    fontWeight: '400',
  },
  highlight: {
    fontWeight: '700',
  },
});

export default App;
