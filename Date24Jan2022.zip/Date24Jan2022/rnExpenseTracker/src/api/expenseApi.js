import { Alert } from "react-native";
import apiClient from "./client";

const endpoint = "/expenses"

const getExpenses = async () => {
    try {
        const res = await apiClient.get(endpoint, {
            headers: {
                Accept: 'application/vnd.github.v3+json'
            }
        });
        console.log("Get response",res);
        let responseData = res.data;
        //Alert.alert("Data size in get request" + responseData.length);
        console.log("Data from get request",responseData);
        return responseData;
    }
    catch (err) {
        console.log("Error in get request", err);
    }

}

const postExpense = async () => {
    try {
        var data = JSON.stringify({ expenseId: 10, expenseTitle: "title10", description: "description1", amount: 1234, paymentStatus: "true", category: "General", expenseDate: new Date() })
        const res = await apiClient.post(endpoint, data, {
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Content-Length": data.length
            }
        });
        console.log("Response from post req",res);
        return true;


    }
    catch (e) {
        console.log("Error in post request", err);
        return false;
    }
}

export default {getExpenses,postExpense}