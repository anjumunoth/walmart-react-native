import {create} from "apisauce";

const apiClient=create({
    baseURL:'http://192.168.29.224:4000'

});

export default apiClient;

// http://localhost:4000
// Replace localhost with ip4 address
// How to get ip4 address
// -- windows in terminal : ipconfig
// -- macos : ifconfig