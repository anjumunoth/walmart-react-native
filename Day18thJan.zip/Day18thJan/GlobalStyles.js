import { StyleSheet } from "react-native";

var styles=StyleSheet.create({
    container:{marginTop:30,width:"100%",height:"100%"},
    textContainer:{backgroundColor:"green",color:"yellow",fontSize:48},
    mainContainer:{backgroundColor:"pink"}
}
)

export default styles;