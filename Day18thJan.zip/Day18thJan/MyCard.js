import React from 'react'

import { View, Text,StyleSheet,Image } from 'react-native'

export default function MyCard({imageUrl,title,desc1,desc2}) {
    console.log(imageUrl);
    return (
        <View style={styles.container}>
            <View style={styles.imageView}>
              
                <Image source={imageUrl} style={styles.imageCard} />
            </View>
            <View style={styles.cardBody}>
                <Text style={styles.textHeader}>{title}</Text>
                <Text style={styles.text}>Price : {desc1}</Text>
                <Text>Quantity : {desc2}</Text>
                
            </View>
        </View>
    )
}

const styles=StyleSheet.create({
    container:{
        marginTop:40,
        flex:1,
        backgroundColor:'pink'
    },
    imageView:{
        justifyContent:'center',
        alignItems:'center',
        flex:2
    },
    imageCard:{
        height:100,
        width:100,
        borderRadius:80,
        borderColor:'black',
        borderWidth:2
    },
    cardBody:{
        flex:2,
        marginVertical:10
    },
    textHeader:{
        fontSize:28,
        fontWeight:"500",
        backgroundColor:"blue",
        color:"pink",
        alignSelf:"center"
    },
    text:{
        fontSize:22
    }
})
