import React from 'react'

import { View, Text,StyleSheet,Image } from 'react-native'

export default function ImageExample() {
    return (
        <View style={styles.container}>
            <Image style={{flex:1}} source={require("./images/samsungFold3.jpg")}></Image>
            <View style={{flex:1, backgroundColor:"pink"}}>
                <Image resizeMode='contain' style={{width:"100%",height:"100%"}} source={{uri:"https://assets.entrepreneur.com/content/3x2/2000/20181008074614-shutterstock-1041718081.jpeg"}} defaultSource={require("./images/googlePixel.jpg")}/>
            </View>
            <View style={{flex:3}}>
                <Image style= {styles.image1} source={require("./images/samsungFold3.jpg")}></Image>
                <Image style= {styles.image2} source={require("./images/oneplus8t.jpg")}></Image>
            </View>
        </View>
    )
}

const styles=StyleSheet.create({
    container:{marginTop:40,flex:1},
    image2:{
        zIndex:10,
        position:'absolute',
        top:100,
        left:100
    },
    image1:
    {   
        zIndex:1
    }
})
