import React,{useState} from 'react';
import { View, Text, StyleSheet ,ScrollView} from 'react-native';
import MyCard from './MyCard';

export default function Products() {
    let [productsArr,setProductsArr]=useState([  
    {productId:"P101",productName:"Apple 13 mini",description:"Apple mini 13 256gb, grey colour",price:85678,quantity:12,imageUrl:require("./images/iphone13Mini.jpg")},
    {productId:"P102",productName:"Samsung fold3",description:"Samsung fold3 256gb, grey colour",price:145678,quantity:7,imageUrl:require("./images/samsungFold3.jpg")},
    {productId:"P103",productName:"One plus 8t",description:"One plus 8t 256gb, grey colour",price:65678,quantity:5,imageUrl:require("./images/oneplus8t.jpg")},
    {productId:"P104",productName:"Google pixel",description:"Google pixel 256gb, grey colour",price:50000,quantity:3,imageUrl:require("./images/googlePixel.jpg")},
    {productId:"P104",productName:"Google pixel",description:"Google pixel 256gb, grey colour",price:50000,quantity:3,imageUrl:require("./images/googlePixel.jpg")},
    {productId:"P104",productName:"Google pixel",description:"Google pixel 256gb, grey colour",price:50000,quantity:3,imageUrl:require("./images/googlePixel.jpg")},
    {productId:"P104",productName:"Google pixel",description:"Google pixel 256gb, grey colour",price:50000,quantity:3,imageUrl:require("./images/googlePixel.jpg")},
    {productId:"P104",productName:"Google pixel",description:"Google pixel 256gb, grey colour",price:50000,quantity:3,imageUrl:require("./images/googlePixel.jpg")},
    {productId:"P104",productName:"Google pixel",description:"Google pixel 256gb, grey colour",price:50000,quantity:3,imageUrl:require("./images/googlePixel.jpg")},
    {productId:"P104",productName:"Google pixel",description:"Google pixel 256gb, grey colour",price:50000,quantity:3,imageUrl:require("./images/googlePixel.jpg")}

    ]);
    let cardsArr=productsArr.map(item =>{
        return (
            <MyCard key={item.productId} 
                imageUrl={item.imageUrl} 
                title={item.productName} 
                desc1={item.price} 
                desc2={item.quantity}>
                  
            </MyCard>
        )
    })
    return (
        <ScrollView style={styles.container}>
           {cardsArr} 
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: "column",
        width:"100%"
    }
})
