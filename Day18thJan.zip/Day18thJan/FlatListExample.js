import React,{useState} from 'react';
import { View, Text,FlatList, StyleSheet } from 'react-native';
import MyCard from './MyCard';

export default function FlatListExample() {
    const [isRefresh,setIsRefresh]=useState(false);
    let [productsArr,setProductsArr]=useState([  
        {productId:"P101",productName:"Apple 13 mini",description:"Apple mini 13 256gb, grey colour",price:85678,quantity:12,imageUrl:require("./images/iphone13Mini.jpg")},
        {productId:"P102",productName:"Samsung fold3",description:"Samsung fold3 256gb, grey colour",price:145678,quantity:7,imageUrl:require("./images/samsungFold3.jpg")},
        {productId:"P103",productName:"One plus 8t",description:"One plus 8t 256gb, grey colour",price:65678,quantity:5,imageUrl:require("./images/oneplus8t.jpg")},
        {productId:"P104",productName:"Google pixel",description:"Google pixel 256gb, grey colour",price:50000,quantity:3,imageUrl:require("./images/googlePixel.jpg")},
        {productId:"P104",productName:"Google pixel",description:"Google pixel 256gb, grey colour",price:50000,quantity:3,imageUrl:require("./images/googlePixel.jpg")},
        {productId:"P104",productName:"Google pixel",description:"Google pixel 256gb, grey colour",price:50000,quantity:3,imageUrl:require("./images/googlePixel.jpg")},
        {productId:"P104",productName:"Google pixel",description:"Google pixel 256gb, grey colour",price:50000,quantity:3,imageUrl:require("./images/googlePixel.jpg")},
        {productId:"P104",productName:"Google pixel",description:"Google pixel 256gb, grey colour",price:50000,quantity:3,imageUrl:require("./images/googlePixel.jpg")},
        {productId:"P104",productName:"Google pixel",description:"Google pixel 256gb, grey colour",price:50000,quantity:3,imageUrl:require("./images/googlePixel.jpg")},
        {productId:"P104",productName:"Google pixel",description:"Google pixel 256gb, grey colour",price:50000,quantity:3,imageUrl:require("./images/googlePixel.jpg")}
    
        ]);
        const onRefreshEventHandler=()=>{
            setIsRefresh(true);
            // talk with the server and get the new/updated data
            setProductsArr(prevProductsArr=>[...prevProductsArr,{productId:"P105",productName:"Nokia",description:"Nokia 3310",price:5000,quantity:10,imageUrl:require("./images/googlePixel.jpg")}])
            setIsRefresh(false)
        }
      const renderItem=({item})=>{
          return (
             
                <MyCard 
                imageUrl={item.imageUrl} 
                title={item.productName} 
                desc1={item.price} 
                desc2={item.quantity}>
                </MyCard>
            
          )
      } 
  return (
    <View style={styles.container}>
      <FlatList 
      data={productsArr}
      renderItem={renderItem}
      refreshing={isRefresh}
      onRefresh={onRefreshEventHandler}  
      keyExtractor={item => (Math.random()*100).toString()}
      ></FlatList>
     </View>
  );
}

const styles=StyleSheet.create({
    container:{
        flex:1,
        width:"100%",
        flexDirection:"column"
    },
    flatListStyle:{
       
    }
})


