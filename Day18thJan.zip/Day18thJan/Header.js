import React from 'react'
import {View,Text,StyleSheet, Button} from "react-native"

function Header(props)
{
    return (
        <View style={styles.container}> 
            <View style={[{backgroundColor:"pink"},styles.block]}></View>
            <View style={[{alignSelf:"flex-start"},styles.block,{backgroundColor:"cyan"}]}></View>
            <View style={[styles.block,{backgroundColor:"yellow"}]}></View>
            <Button title="Register" color="red"></Button>
        </View>

    );
}

var styles=StyleSheet.create(
    {
        container:{marginTop:30,
            flex:1,
            flexDirection:"column",
            justifyContent:"center",
            alignItems:"flex-end",
            backgroundColor:"pink"
        },
        block:{width:100,height:100,backgroundColor:"violet"}
}

)


export default Header;
//int i=10; i=20;SOP(i);//20
//var obj={empId:101,empName:"sara",empId:999}; clg(obj);//{999,sara}
// !important -- flex

// flexDirection --row : justifyContent -- adjust the items horizontally
// flexDirection --column ; justifyContent-- adjust the items vertically


