import React, { Component } from 'react'

class AddToCart extends Component {
    constructor(props)
    {
        super(props);
        this.state={
            quantitySelected:1,
            selectedProduct:this.props.selectedProduct};
    }
    incQuantityEventHandler=()=>{
        console.log("Inc button clicked");
        var maxQuantity=this.props.selectedProduct.quantity;
        if(this.state.quantitySelected <maxQuantity)
        {
            this.setState((prevState)=>{
                return ({quantitySelected:prevState.quantitySelected+1})
            });
        }
    }
    decQuantityEventHandler=()=>{
        if(this.state.quantitySelected >1)
        {
            this.setState((prevState)=>{
                return ({quantitySelected:prevState.quantitySelected-1})
            });
        }
    }
    // another lifecycle method
    static getDerivedStateFromProps(newProps,prevState)
    {
        // method is invoked the first time after the constructor
        // method is also invoked whenever props changes
        // check if the props has changed -- if yes, reset the quantity to 1
        console.log("Get derived state from props called");
        if(newProps.selectedProduct.productId !== prevState.selectedProduct.productId)
        {
            return {...prevState,quantitySelected:1,selectedProduct:newProps.selectedProduct};
        }
        else
            return {...prevState};
    }
    cancelSelectionEventHandler=()=>{
        // send some control back to parent
        // trigger a custom event -- onCancel 
        this.props.onCancel();
    }
    componentWillUnmount(){
        // invoked just before the component gets unmounted
        //this.setState();// meaningless
        // unsubscriptions from third party API; do some logout operations
        alert("Add To cart is getting unmounted");

    }
    confirmSelectionEventHandler=()=>{
        alert("button Confirm clicked");
        // pass some data along with triggering the event
        var cartObj={...this.props.selectedProduct,quantitySelected:this.state.quantitySelected};
        this.props.onConfirm(cartObj);
    }
    render() {
        //var item = this.props.selectedProduct;//reference
        var item = { ...this.props.selectedProduct };//copy

        return (
            <React.Fragment>
                <h1> Add To cart Component</h1>
                <h2> Company Name :{this.props.companyName} </h2>
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-4 offset-4">
                            <div className='card bg-warning m-2 border border-5 border-primary' style={{ width: "18rem" }}>
                                <img src={item.imageUrl}
                                    alt={item.description}
                                    className='card-img-top' />
                                <div className='card-body'>
                                    <h1 className='card-title'>{item.productName}</h1>
                                    <p className='card-text'> Price : Rs.{item.price}</p>
                                    <p className='card-text'> Quantity : {item.quantity}</p>

                                    <input type="button" value="-" 
                                        className='btn btn-primary' 
                                        disabled={this.state.quantitySelected ===1} 
                                        onClick={this.decQuantityEventHandler}/>
                                    {this.state.quantitySelected}
                                    <input type="button" value="+" 
                                        className='btn btn-primary' 
                                        onClick={this.incQuantityEventHandler}
                                        disabled={this.state.quantitySelected === item.quantity}/>

                                    <br/>
                                    <input type="button" value="Confirm selection"  className='btn btn-primary m-2' 
                                    onClick={this.confirmSelectionEventHandler}/>

                                    <input type="button" value="Cancel"  className='btn btn-primary'  
                                    onClick={this.cancelSelectionEventHandler} />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </React.Fragment>
        );
    }
}
export class Sample extends Component {
    render() {
        return (
            <React.Fragment>
                <h1> Sample Component</h1>

            </React.Fragment>
        );
    }
}
export default AddToCart;


/*
Component -- state and props
state- managing mutable data of that component
props -- immutable data ; data coming from the parent
*/


