import React, { Component } from 'react'
import { Route, Switch } from 'react-router-dom'
import AboutUs from './AboutUs'
import ContactUs from './ContactUs'
import Register from './Register'
import Details from './Details'
import Cart from './Cart'
import ProductDisplay from './ProductDisplay'

export default class Home extends Component {
    constructor()
  {
    super();
    this.state={
      showCart:false,
      cartArr:[],
      productsArr:[
        {productId:"P101",productName:"Apple 13 mini",description:"Apple mini 13 256gb, grey colour",price:85678,quantity:12,imageUrl:"images/iphone13Mini.jpg"},
        {productId:"P102",productName:"Samsung fold3",description:"Samsung fold3 256gb, grey colour",price:145678,quantity:7,imageUrl:"images/samsungFold3.jpg"},
        {productId:"P103",productName:"One plus 8t",description:"One plus 8t 256gb, grey colour",price:65678,quantity:5,imageUrl:"images/oneplus8t.jpg"},
        {productId:"P104",productName:"Google pixel",description:"Google pixel 256gb, grey colour",price:50000,quantity:3,imageUrl:"images/googlePixel.jpg"}
    ]
      
    };
  }
  onCartDataToAppEventHandler=(cartObj)=>{
    // modify the quantity
    var tempObj={...this.state.productsArr.find(item => item.productId === cartObj.productId)};
    tempObj.quantity-=cartObj.quantitySelected;

    this.setState((prevState)=>{
        var pos=prevState.productsArr.findIndex(item => item.productId === cartObj.productId);
        prevState.productsArr[pos].quantity-=cartObj.quantitySelected;
        return {...prevState};
    })
    this.setState((prevState)=>{
      var pos=prevState.cartArr.findIndex(item => item.productId ===cartObj.productId)
      if(pos >=0)
      {
        prevState.cartArr[pos].quantitySelected+=cartObj.quantitySelected;
        return ({cartArr:prevState.cartArr});
      }
      return(
        {cartArr:[...prevState.cartArr,cartObj]}
      );
      },()=>{
      console.log("In App component",this.state.cartArr);
    });
  }
    render() {
        return (
            <React.Fragment>
                <Switch>
                    <Route path="/cart" >
                        <Cart cartArr={this.state.cartArr}></Cart>
                    </Route>
                    <Route path="/products">
                        <ProductDisplay
                            productsArr={this.state.productsArr}
                            onCartDataToApp={this.onCartDataToAppEventHandler}>
                        </ProductDisplay>
                    </Route>
                    <Route path="/details/:pId" component={Details}></Route>
                    <Route path="/details" component={Details}></Route>
                    <Route path="/" exact component={Register}></Route>
                    <Route path="/aboutus" component={AboutUs}></Route>
                    <Route path="/contactus" component={ContactUs}></Route>
                    <Route path="/register" component={Register}></Route>
                    <Route render={() => { return (<div><h1>Page Not Found</h1></div>); }} ></Route>
                </Switch>
            </React.Fragment>
        )
    }
}


/*
11-1-2022 -- Redux
12-1-2022 -- Hooks and React native introduction
13-1-2022 -- React native -- core components
14-1-2022 -- holiday
*/