// class component -- Header
import React from 'react'

import walmartLogo from "./walmartLogo.png"
import "./Header.css";

class Header extends React.Component
{

    // lifecycle method of a component
    render()
    {
       
        return (
            <div className='container-fluid'>
                <div className='row bg-warning align-items-center'>
                    <img className='col-6' src={walmartLogo} alt="Logo of Walmart"/>
                    <h1 className='col-6 header1'>Shopping</h1>
                </div>
               
            </div>
        );
    }
}

export default Header;
/*
lifecycle method of a component:
constructor in a class- initialise the various members of the object
-- called implicitly whenever an object is created
-- can the constructor be called explicitly without creating the object -- no
-- lifecycle method of a component-- first method which will be invoked during the lifecycle of the component
-- how many times is the constructor invoked during the lifecycle -- once

render -- used to return the virtual DOM
-- called implicitly whenever an object is created after the constructor
-- can the render be called explicitly without creating the object -- no
-- how many times is the render invoked during the lifecycle -- many
--

Employee emp=new Employee();
SOP(emp);// hash code of object



*/
