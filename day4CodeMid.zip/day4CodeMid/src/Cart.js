import React from 'react'

class Cart extends React.Component
{
    constructor(props)
    {
        super(props);
        console.log("Props in Cart",this.props);
        
        this.state={cartArr:this.props.cartArr };
        console.log("State in Cart",this.state);
    }

    render()
    {
        var trArr=this.state.cartArr.map(item =>{
            return (
                <tr>
                    <td><img src={item.imageUrl} alt={item.description} className='img-responsive'/></td>
                    <td> {item.productName}</td>
                    <td> {item.price}</td>
                    <td> {item.quantitySelected}</td>
                </tr>
            );
        })
        return(
            <React.Fragment>
                <h1>Cart Component</h1>
                <table className='table'>
                    <thead>
                        <tr>
                            <td> Image</td>
                            <td>Product Name</td>
                            <td> Price</td>
                            <td> Quantity Selected</td>
                        </tr>
                    </thead>
                    <tbody>
                        {trArr.length > 0?trArr:"No items added to Cart"}
                    </tbody>
                </table>
            </React.Fragment>
        )
    }
}

export default Cart;