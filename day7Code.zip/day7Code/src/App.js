import logo from './logo.svg';
import './App.css';
import Header from "./Header";
import Footer from "./Footer";
import ProductDisplay from './ProductDisplay';
import React from 'react';
import Cart from './Cart';
import Register from './Register';
import ProductEdit from "./ProductEdit"
import Menu from './Menu';
import Home from "./Home"

// component -- return a virtual DOM
class App extends React.Component {
  
  render() {
    return (
      <React.Fragment>
        <Header></Header>

        <Menu></Menu>
        <Home></Home>
        <Footer></Footer>
      </React.Fragment>
    );
  }
}



export default App;
// npx create-react-app first_project

/*
<Header></Header>
        <div className='container-fluid'>
          <div className='row'>
            <div className='col-1 offset-11'>
              {this.state.showCart
              ?
              <input type="button" className= "btn btn-primary" 
              value="Products" 
              onClick={()=>{this.setState({showCart:false})}} />

              :
              <input type="button" className= "btn btn-primary"  
              value="Cart" 
              onClick={()=>{this.setState({showCart:true})}} /> }
            </div>
          </div>
         
       </div>
        <div>
        {this.state.showCart 
        ?  <Cart cartArr={this.state.cartArr}></Cart>
        :  <ProductDisplay 
          productsArr={this.state.productsArr}
          onCartDataToApp={this.onCartDataToAppEventHandler}>
        </ProductDisplay>}
        </div>
       
        <Footer></Footer>
*/