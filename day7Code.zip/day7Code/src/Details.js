import React, { Component } from 'react'

export default class Details extends Component {
    goBackEventHandler=()=>{
        //this.props.history.push("/aboutus");
        this.props.history.go(-1);
        //this.props.history.goBack();

    }
    render() {
        console.log("Details props",this.props);
        var productId = this.props.match.params.pId ? this.props.match.params.pId: "Unknown";
        var productDetails= this.props.location.state?.productDetails;
        
;        return (
            <div>
                <h1>Details Component</h1>
                <h2>Product Id : {productId}</h2> 
                {productDetails && <h2>ProductName : {productDetails.productName}</h2>}
                <input type="button" value ="Go Back" onClick={this.goBackEventHandler}/>

            </div>
        )
    }
}

/*
props -- data flowing from the parent
props -- immutable data

*/

/*
var obj={empId:101,empName:"sara",salary:56789}
destructuring an object
clg(obj.empId);
var {empId}=obj;
clg(empId);

constructor({history,location})
{
    clg(history);// no need to say this.props.history
}
*/

/*
Pass data between 2 components
1. Parent to Child -- using props
2. child to parent -- using events and event emitters
3. 2 siblings -- lifted the state to a common parent and prop drilling
4. 2 components -- redux
5. 2 components -- routing -- route's state and route's params
*/

/*
register page --> once everything goes well --> home page 
home page -- > click back button of the browser --> will go to register page --> user may register again

register page --> naviagate to home page by using replace



*/
