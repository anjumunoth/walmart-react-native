import React, { Component } from 'react'

export default class AboutUs extends Component {
    constructor(props)
    {
        super(props);
        this.state={productName:""};
        this.productIdRef=React.createRef();
    }
    gotoDetailsEventHandler=()=>{
        this.props.history.push("/details");
    }
    gotoDetailsWithParamsEventHandler=()=>{
        if(this.productIdRef.current.value)
        {
        this.props.history.push("/details/"+ this.productIdRef.current.value);
        }
        else
        {
            alert("Product id should not be empty");
        }
    }
    onChangeProductNameEventHandler=(event)=>{
        this.setState({productName:event.target.value})
    }
    gotoDetailsWithObjectEventHandler=()=>{
        if(this.productIdRef.current.value)
        {
            if(this.state.productName !== "")
            {
                // send an object 
                var obj={productId:this.productIdRef.current.value,productName: this.state.productName};

                //this.props.history.push("/details/"+ this.productIdRef.current.value,{productDetails:obj});
                this.props.history.replace("/details/"+ this.productIdRef.current.value,{productDetails:obj});
            }
                
        }
        else
        {
            alert("Product id should not be empty");
        }
    }
    render() {
        return (
            <div>
                <h1>AboutUs Component</h1>
                <form>
                    <input type="text" ref={this.productIdRef}/>
                    <input type="text" placeholder='Enter the productName' onChange={this.onChangeProductNameEventHandler}/>
                    <input type="button" value="Go to Details" onClick={this.gotoDetailsEventHandler}/>
                    <input type="button" value="Go to Details with params" onClick={this.gotoDetailsWithParamsEventHandler}/>
                    <input type="button" value="Go to Details with productObject" onClick={this.gotoDetailsWithObjectEventHandler}/>
                    <h2> Product Name : {this.state.productName}</h2>
                </form>
            </div>
        )
    }
}
