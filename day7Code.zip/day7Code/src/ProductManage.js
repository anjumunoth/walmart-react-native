import React, { Component } from 'react'

export default class ProductManage extends Component {
    render() {
        return (
            <div>
                <table className='table'>
                    <thead>
                        <tr>
                            <th>ProductId</th>
                            <th>ProductName</th>
                            <th>Price</th>
                            <th>Quantity</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                            <h1>Hello</h1>
                            </td>
                        </tr>
                        
                    </tbody>
                </table>
            </div>
        )
    }
}
