function productReducer(state, action) {
    var newState = { ...state };
    switch (action.type) {
        case "ADD_PRODUCT":
            var pos = newState.productsArr.findIndex(item => item.productId === action.payload.productId);
            if (pos < 0) {
                newState.productsArr.push(action.payload);
            }
            break;
        case "DELETE_PRODUCT":
            var pos = newState.productsArr.findIndex(item => item.productId === action.payload.productId);
            if (pos >= 0) {
                newState.productsArr.splice(pos, 1,);
            }
            break;
        case "UPDATE_PRODUCT":
            var pos = newState.productsArr.findIndex(item => item.empId === action.payload.empId);
            if (pos >= 0) {
                newState.productsArr.splice(pos, 1, action.payload);
            }

            break;
    }
    return newState;
}

export default productReducer;
